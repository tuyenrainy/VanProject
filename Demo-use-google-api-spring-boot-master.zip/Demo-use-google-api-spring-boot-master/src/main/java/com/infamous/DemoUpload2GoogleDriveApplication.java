package com.infamous;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class DemoUpload2GoogleDriveApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoUpload2GoogleDriveApplication.class, args);
	}
}
